export default () => (
    <style jsx global>{`
      .classe {
        display: none !important;
      }
    `}</style>
  );
  