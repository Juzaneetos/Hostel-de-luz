import axios from "axios";
// import Cropper from "react-cropper";
// import "cropperjs/dist/cropper.css";

import { toast } from "react-toastify";
import router from 'next/router';
import Link from "next/link";
import bg1 from '../../assets/img/quarto-de-luxo-no-hotel.jpg'
import Image from "next/image";
import { FaEdit, FaCheck, FaTrash } from "react-icons/fa";
import { useState, useEffect, useRef } from "react";

import { ref, uploadBytesResumable, getDownloadURL, getStorage, deleteObject } from 'firebase/storage';
import { storage } from '../../firebase';

import useSwr, { mutate } from "swr";
const fetcher = (url) => fetch(url).then((res) => res.json());

import Menu from "../../components/b2b_components/Menu";

export default function Checkin() {
  const { data: hoteis } = useSwr(`/api/hoteis/getAllHotel`, fetcher);
  const { data: quartos } = useSwr(`/api/quartos/getAllQuarto`, fetcher);
  const [Name, setName] = useState("");
  const [rg, setRg] = useState("");
  const [cpf, setCpf] = useState("");
  const [passaporte, setPassaporte] = useState("");
  const [entrada, setEntrada] = useState("")
  const [saida, setSaida] = useState("")
  const [formapagamento, setFormaPagamento] = useState("")
  const [observacoes, setObservações] = useState("")
  const [valorpago, setValorpago] = useState(0)
  const [hotel, setHotel] = useState("");
  const [quarto, setQuarto] = useState([]);
  const [nomequarto, setNomeQuarto] = useState('');
  const [genero, setGenero] = useState("");
  const [idquarto, setIdquarto] = useState("");
  const [qtdcamas, setQtdcamas] = useState(0);
  const [objreserva, setObjreserva] = useState([]);
  const [active, setActive] = useState('1');
  const [pagamentoconcluido, setPagamentoConcluido] = useState('0');

  console.log(quartos)
  const registrarQuarto = (numerocama) => {
    setObjreserva({
      hotel: hotel,
      quarto: idquarto,
      cama: numerocama,
    })
  }

  const dispararcheckin = () => {
    setTimeout( async () => {
      let data = await axios.post(`/api/checkin/insertCheckin`, {
        nome: Name,
        rg: rg,
        cpf: cpf,
        passaporte: passaporte,
        genero: genero,
        entrada: entrada,
        diaLimpeza: entrada,
        saida: saida,
        formapagamento: formapagamento,
        valorpago: valorpago,
        observacoes: observacoes,
        objreserva: objreserva,
        ativado: active,
        pagamentoconcluido: pagamentoconcluido,
      });
      alert('oi')
      router.push("/b2b/quartos");
    }, 5000)
  }


  const dispararbanco = async () => {
    let contador = 0;
    let titulo_ = '';
    let camas = '';
    let arrCamas = [];
    let hotel_ = '';
    let genero_ = '';
    let ativado = '';
    quartos?.map((item, index) => {
      contador++
      if (item._id === objreserva.quarto) {
        item.arrCamas?.map((item2, index) => {
          if (item2.numeroCama === objreserva.cama) {
            item2.vago = true;
            item2.hospede = Name;
            item2.entrada = entrada;
            titulo_ = item.titulo;
            camas = item.camas;
            arrCamas = item.arrCamas;
            hotel_ = item.hotel;
            genero_ = item.genero;
            ativado = item.ativado;
          }
        })
      }
    })

    if (quartos.length === contador) {
      try {

        const response2 = await axios.post(`/api/checkin/insertCheckin`, {
          nome: Name,
          rg: rg,
          cpf: cpf,
          passaporte: passaporte,
          genero: genero,
          entrada: entrada,
          diaLimpeza: entrada,
          saida: saida,
          formapagamento: formapagamento,
          valorpago: valorpago,
          observacoes: observacoes,
          objreserva: objreserva,
          ativado: active,
          pagamentoconcluido: pagamentoconcluido,
        });
        
        const response1 = await axios.post(`/api/quartos/updateQuarto?id=${objreserva.quarto}`, {
          titulo: titulo_,
          camas: camas,
          arrCamas: arrCamas,
          hotel: hotel_,
          genero: genero_,
          ativado: ativado,
        });
        // Executa a segunda solicitação apenas se a primeira for concluída com sucesso
        
        alert('oi')
        router.push("/b2b/quartos");
      } catch (error) {
        console.error(error);
      }
    }

  }

  return (
    <div style={{ backgroundColor: '#f3f3f3' }}>
      <div style={{ display: 'flex' }}>
        <Menu />
        <div className="ec-page-wrapper">
          <div className="ec-content-wrapper">
            <div className="content">
              <div className="breadcrumb-wrapper d-flex align-items-center justify-content-between">
                <div>
                  <h1>Adicionar Quarto</h1>
                  <p className="breadcrumbs">
                    <span>
                      <Link href="/b2b">Dashboard</Link>
                    </span>
                    <span>
                      <i className="mdi mdi-chevron-right"></i>
                    </span>
                    Adicionar Quarto
                  </p>
                </div>
              </div>
              <div className="row">
                <div className="col-12">
                  <div className="card card-default">
                    <div className="card-body">
                      <div className="row ec-vendor-uploads">
                        <div className="col-lg-12">
                          <div className="ec-vendor-upload-detail">
                            <form
                              className="row g-3"
                              encType="multipart/form-data"
                            >

                              <div className="col-md-12">
                                <label htmlFor="inputEmail4" className="form-label">
                                  Nome
                                </label>
                                <input
                                  type="text"
                                  className="form-control slug-title"
                                  id="inputEmail4"
                                  onChange={(e) => setName(e.target.value)}
                                />
                              </div>

                              <div className="col-md-6">
                                <label className="form-label">RG</label>
                                <input
                                  type="text"
                                  className="form-control slug-title"
                                  id="inputEmail4"
                                  onChange={(e) => setRg(e.target.value)}
                                />
                              </div>
                              <div className="col-md-6">
                                <label className="form-label">CPF</label>
                                <input
                                  type="text"
                                  className="form-control slug-title"
                                  id="inputEmail4"
                                  onChange={(e) => setCpf(e.target.value)}
                                />
                              </div>
                              <div className="col-md-6">
                                <label className="form-label">Passaporte</label>
                                <input
                                  type="text"
                                  className="form-control slug-title"
                                  id="inputEmail4"
                                  onChange={(e) => setPassaporte(e.target.value)}
                                />
                              </div>
                              <div className="col-md-6">
                                <label className="form-label">Genero</label>
                                <select onChange={(e) => setGenero(e.target.value)}>
                                  <option value={''} selected></option>
                                  <option value={'masculino'} >Masculino</option>
                                  <option value={'feminino'}>Feminino</option>
                                  <option value={'unisex'}>Unisex</option>
                                </select>
                              </div>
                              <div className="col-md-6">
                                <label className="form-label">Entrada</label>
                                <input
                                  type="date"
                                  className="form-control slug-title"
                                  id="inputEmail4"
                                  onChange={(e) => setEntrada(e.target.value)}
                                />
                              </div>
                              <div className="col-md-6">
                                <label className="form-label">Saida</label>
                                <input
                                  type="date"
                                  className="form-control slug-title"
                                  id="inputEmail4"
                                  onChange={(e) => setSaida(e.target.value)}
                                />
                              </div>

                              <div className="col-md-6">
                                <label className="form-label">Forma de Pagamento</label>
                                <select onChange={(e) => setFormaPagamento(e.target.value)}>
                                  <option value={''} selected></option>
                                  <option value={'dinheiro'} >Dinheiro</option>
                                  <option value={'pix'} >Pix</option>
                                  <option value={'debito'}>Débito</option>
                                  <option value={'credito'}>Crédito</option>
                                  <option value={'cheque'}>Cheque</option>
                                </select>
                              </div>

                              <div className="col-md-6">
                                <label className="form-label">Valor Pago</label>
                                <input
                                  type="number"
                                  className="form-control slug-title"
                                  id="inputEmail4"
                                  style={{ height: '40%' }}
                                  onChange={(e) => setValorpago(e.target.value)}
                                />
                              </div>
                              <div className="col-md-12">
                                <label className="form-label">Observações</label>
                                <textarea
                                  rows={5}
                                  className="form-control slug-title"
                                  id="inputEmail4"
                                  onChange={(e) => setObservações(e.target.value)}
                                />
                              </div>

                              <h3 className="text-center"> Escolha o Hotel </h3>
                              <div className="col-md-12 d-flex">
                                {hoteis?.map((item, index) => {
                                  console.log(item)
                                  return (
                                    <div className={`col-md-6`} style={{ position: 'relative', height: '200px', overflow: 'hidden' }}>
                                      <Image width={1000} height={1000} className='pl-3 pr-3' style={{ opacity: '0.5' }} src={item.imagem[0].url} />
                                      <div className={`circulohotel d-flex flex-column ${hotel === item._id ? 'bg-black' : ''}`} style={{ position: 'absolute', fontWeight: '700' }} onClick={() => setHotel(item._id)}>
                                        {item.titulo}

                                      </div>
                                    </div>
                                  )
                                })}
                              </div>

                              {hotel.length > 0 ?
                                <>
                                  <h3 className="text-center"> Escolha o Quarto </h3>
                                  <div className="col-md-12 d-flex justify-content-center">
                                    {quartos?.map((item, index) => {
                                      let contadordisponivel = 0;
                                      if (item.hotel === hotel) {
                                        return (
                                          <>
                                            <div className="col-md-3" style={{ position: 'relative', height: '200px', overflow: 'hidden' }}>
                                              <Image width={1000} height={1000} className='pl-3 pr-3' style={{ opacity: '0.5' }} src={require('../../assets/img/luxo-classico-moderno-quarto-suite-em-hotel.jpg')} />
                                              <div className={`circuloquarto d-flex flex-column ${idquarto === item._id ? 'bg-black' : ''}`} style={{ position: 'absolute', fontWeight: '700' }} onClick={() => { setQuarto(item.arrCamas), setNomeQuarto(item.titulo), setIdquarto(item._id) }}>
                                                {item.titulo}
                                                <div>{item.genero} </div>
                                                {item.arrCamas?.map((item2, index) => {
                                                  console.log(item2.vago)
                                                  if (item2.vago === false) {
                                                    contadordisponivel++;
                                                  }
                                                  if (item.arrCamas.length === index + 1) {
                                                    return (
                                                      <div>Disponiveis: {contadordisponivel} </div>
                                                    )

                                                  }
                                                })}
                                              </div>
                                            </div>

                                          </>
                                        )
                                      }
                                    })}
                                  </div>
                                </>
                                :
                                <></>
                              }


                              {quarto.length > 0 ?
                                <>
                                  <h3 className="text-center">{nomequarto}</h3>
                                  <div className="col-12 d-flex justify-content-center mb-3">
                                    <div className="col-10 d-flex justify-content-center align-items-center" style={{ height: '200px', border: '3px solid black' }}>
                                      {quarto?.map((item2, index) => {
                                        return (
                                          <>
                                            {item2.vago ?
                                              <div style={{ position: 'relative' }}>
                                                <Image width={70} height={70} className='pl-3 pr-3' style={{ opacity: '0.5' }} src={require('../../assets/img/cama-de-solteiro.png')} />
                                                <div className={`bg-black circulocama d-flex flex-column`} style={{ position: 'absolute', fontWeight: '700' }} onClick={() => alert('Ja reservado')}>
                                                  {item2.numeroCama}
                                                  <p>{item2.vago ? item2.hospede : 'Liberado'}</p>
                                                </div>
                                              </div>
                                              :
                                              <div style={{ position: 'relative' }} >
                                                <Image width={70} height={70} className='pl-3 pr-3' style={{ opacity: '0.5' }} src={require('../../assets/img/cama-de-solteiro.png')} />
                                                <div className={`${objreserva.cama === item2.numeroCama ? 'bg-black' : ''} circulocama d-flex flex-column`} style={{ position: 'absolute', fontWeight: '700' }} onClick={() => registrarQuarto(item2.numeroCama)}>
                                                  {item2.numeroCama}
                                                  <p>{item2.vago ? item2.hospede : 'Liberado'}</p>
                                                </div>
                                              </div>
                                            }
                                          </>
                                        )
                                      })}


                                    </div>
                                  </div>
                                </>
                                :
                                <></>
                              }


                              <div className="d-flex mb-3 col-md-6 justify-content-center mt-4">
                                <div className="row align-items-center">
                                  <label className="form-label">Ativado</label>
                                  <div className="col-auto d-flex align-items-center" style={{ height: '50px' }}>
                                    <input
                                      type="radio"
                                      name="active"
                                      value={1}
                                      style={{ width: '20px', margin: '0 15px 0 0' }}
                                      onChange={(e) => setActive(e.target.value)}
                                    />
                                    Sim
                                  </div>
                                  <div className="col-auto d-flex align-items-center" style={{ height: '50px' }}>
                                    <input
                                      type="radio"
                                      name="active"
                                      value={0}
                                      style={{ width: '20px', margin: '0 15px 0 0' }}
                                      onChange={(e) => setActive(e.target.value)}
                                    />
                                    Não
                                  </div>
                                </div>
                              </div>

                              <div className="d-flex mb-3 col-md-6 justify-content-center mt-4">
                                <div className="row align-items-center">
                                  <label className="form-label">Pagamento Concluído</label>
                                  <div className="col-auto d-flex align-items-center" style={{ height: '50px' }}>
                                    <input
                                      type="radio"
                                      name="pagamento"
                                      value={1}
                                      style={{ width: '20px', margin: '0 15px 0 0' }}
                                      onChange={(e) => setPagamentoConcluido(e.target.value)}
                                    />
                                    Sim
                                  </div>
                                  <div className="col-auto d-flex align-items-center" style={{ height: '50px' }}>
                                    <input
                                      type="radio"
                                      name="pagamento"
                                      value={0}
                                      style={{ width: '20px', margin: '0 15px 0 0' }}
                                      onChange={(e) => setPagamentoConcluido(e.target.value)}
                                    />
                                    Não
                                  </div>
                                </div>
                              </div>

                              <div className="col-md-12">
                                <div onClick={() => dispararbanco()} className="btn btn-primary">
                                  Adicionar Produto
                                </div>
                              </div>
                            </form>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export const getServerSideProps = async (ctx) => {

  const myCookie = ctx.req?.cookies || "";

  if (myCookie.access_token !== process.env.TOKEN) {
    return {
      redirect: {
        destination: "/b2b/login",
        permanent: false,
      },
    };
  }

  return {
    props: {},
  };
}